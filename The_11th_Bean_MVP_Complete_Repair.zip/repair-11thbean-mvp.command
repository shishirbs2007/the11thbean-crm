#!/usr/bin/env bash
set -Eeuo pipefail
IFS=$'\n\t'

START_DIR="$(pwd)"
STAMP="$(date +%Y%m%d-%H%M%S)"
LOG=""
BACKUP=""

green=$'\033[32m'
yellow=$'\033[33m'
red=$'\033[31m'
reset=$'\033[0m'

pass(){ printf "%s[PASS]%s %s\n" "$green" "$reset" "$*"; }
warn(){ printf "%s[WARN]%s %s\n" "$yellow" "$reset" "$*"; }
fail(){ printf "%s[FAIL]%s %s\n" "$red" "$reset" "$*"; }

find_root() {
  local current="$START_DIR"
  local found
  while [[ "$current" != "/" ]]; do
    if [[ -f "$current/package.json" && -d "$current/src/app" ]]; then
      printf "%s" "$current"
      return 0
    fi
    found="$(find "$current" -maxdepth 3 -type f -name package.json 2>/dev/null | while read -r file; do
      dir="$(dirname "$file")"
      [[ -d "$dir/src/app" ]] && { printf "%s\n" "$dir"; break; }
    done)"
    if [[ -n "$found" ]]; then
      printf "%s" "$found"
      return 0
    fi
    current="$(dirname "$current")"
  done
  return 1
}

ROOT="$(find_root || true)"
[[ -n "$ROOT" ]] || { fail "Could not find the project folder."; exit 1; }

cd "$ROOT"
LOG="$ROOT/MVP_REPAIR_LOG_${STAMP}.txt"
BACKUP="$ROOT/.mvp-repair-backups/$STAMP"
mkdir -p "$BACKUP"

exec > >(tee -a "$LOG") 2>&1

printf "The 11th Bean MVP Repair\n"
printf "Project: %s\n\n" "$ROOT"

cp -R src "$BACKUP/src"
[[ -f package.json ]] && cp package.json "$BACKUP/"
[[ -f package-lock.json ]] && cp package-lock.json "$BACKUP/"
pass "Backup created: $BACKUP"

# Remove the original placeholder route if it still exists.
if [[ -f "src/app/customers/page.tsx" ]]; then
  rm "src/app/customers/page.tsx"
  pass "Removed duplicate /customers placeholder route"
fi
rmdir "src/app/customers" 2>/dev/null || true

mkdir -p \
  'src/app/(app)/customers' \
  'src/app/(app)/customers/new' \
  'src/app/(app)/customers/[id]' \
  'src/app/(app)/communities' \
  'src/app/(app)/events' \
  'src/app/(app)/dashboard'

cat > 'src/app/(app)/customers/page.tsx' <<'EOF'
import Link from "next/link";
import { requireUser } from "@/lib/auth";

type CustomerListItem = {
  id: string;
  first_name: string;
  last_name: string | null;
  preferred_name: string | null;
  phone: string | null;
  email: string | null;
  company: string | null;
  customer_status: string;
  created_at: string;
};

export default async function CustomersPage({
  searchParams,
}: {
  searchParams: Promise<{ q?: string }>;
}) {
  const { supabase } = await requireUser();
  const { q = "" } = await searchParams;

  let query = supabase
    .from("people")
    .select(
      "id, first_name, last_name, preferred_name, phone, email, company, customer_status, created_at",
    )
    .eq("is_active", true)
    .order("created_at", { ascending: false })
    .limit(100);

  if (q.trim()) {
    const term = q.trim().replaceAll(",", " ");
    query = query.or(
      `first_name.ilike.%${term}%,last_name.ilike.%${term}%,preferred_name.ilike.%${term}%,phone.ilike.%${term}%,email.ilike.%${term}%,company.ilike.%${term}%`,
    );
  }

  const { data, error } = await query;
  const people: CustomerListItem[] = (data ?? []) as CustomerListItem[];

  return (
    <main className="mx-auto max-w-7xl px-5 py-10">
      <div className="flex flex-wrap items-center justify-between gap-4">
        <div>
          <h1 className="text-3xl font-semibold">Customers</h1>
          <p className="mt-2 text-neutral-600">
            Search and build a complete hospitality profile.
          </p>
        </div>
        <Link
          href="/customers/new"
          className="rounded-xl bg-black px-4 py-3 text-sm text-white"
        >
          Add customer
        </Link>
      </div>

      <form className="mt-7 flex gap-2">
        <input
          name="q"
          defaultValue={q}
          placeholder="Search name, phone, email or company"
          className="w-full rounded-xl border px-4 py-3"
        />
        <button className="rounded-xl border px-5">Search</button>
      </form>

      {error && <p className="mt-5 text-red-700">{error.message}</p>}

      <div className="mt-6 overflow-hidden rounded-2xl border">
        {people.length === 0 ? (
          <p className="p-6 text-neutral-600">No matching customers yet.</p>
        ) : (
          people.map((person) => (
            <Link
              key={person.id}
              href={`/customers/${person.id}`}
              className="grid gap-1 border-b p-5 last:border-b-0 hover:bg-neutral-50 sm:grid-cols-3"
            >
              <div className="font-medium">
                {person.preferred_name || person.first_name}{" "}
                {person.last_name || ""}
              </div>
              <div className="text-sm text-neutral-600">
                {person.phone || person.email || "No contact"}
              </div>
              <div className="text-sm text-neutral-500 sm:text-right">
                {person.company || person.customer_status}
              </div>
            </Link>
          ))
        )}
      </div>
    </main>
  );
}
EOF

cat > 'src/app/(app)/communities/page.tsx' <<'EOF'
import { requireUser } from "@/lib/auth";
import { createCommunity } from "./actions";

type CommunityItem = {
  id: string;
  name: string;
  description: string | null;
  is_active: boolean;
};

export default async function CommunitiesPage({
  searchParams,
}: {
  searchParams: Promise<{ error?: string }>;
}) {
  const { error: queryError } = await searchParams;
  const { supabase } = await requireUser();

  const { data, error } = await supabase
    .from("communities")
    .select("id, name, description, is_active")
    .order("name");

  const communities: CommunityItem[] = (data ?? []) as CommunityItem[];

  return (
    <main className="mx-auto max-w-7xl px-5 py-10">
      <h1 className="text-3xl font-semibold">Communities</h1>
      <p className="mt-2 text-neutral-600">
        Clubs, circles and recurring groups around the café.
      </p>

      {(queryError || error) && (
        <p className="mt-4 text-red-700">
          {queryError || error?.message}
        </p>
      )}

      <form
        action={createCommunity}
        className="mt-7 grid gap-3 rounded-2xl border p-5 sm:grid-cols-2"
      >
        <input
          name="name"
          required
          placeholder="Community name"
          className="rounded-xl border px-4 py-3"
        />
        <input
          name="description"
          placeholder="Description"
          className="rounded-xl border px-4 py-3"
        />
        <button className="rounded-xl bg-black px-4 py-3 text-white sm:col-span-2">
          Create community
        </button>
      </form>

      <div className="mt-6 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
        {communities.length === 0 ? (
          <p className="text-neutral-600">No communities yet.</p>
        ) : (
          communities.map((community) => (
            <article key={community.id} className="rounded-2xl border p-5">
              <h2 className="font-semibold">{community.name}</h2>
              <p className="mt-2 text-sm text-neutral-600">
                {community.description || "No description"}
              </p>
            </article>
          ))
        )}
      </div>
    </main>
  );
}
EOF

cat > 'src/app/(app)/events/page.tsx' <<'EOF'
import { requireUser } from "@/lib/auth";
import { createEvent } from "./actions";

type EventItem = {
  id: string;
  name: string;
  starts_at: string;
  location: string | null;
  capacity: number | null;
};

export default async function EventsPage({
  searchParams,
}: {
  searchParams: Promise<{ error?: string }>;
}) {
  const { error: queryError } = await searchParams;
  const { supabase } = await requireUser();

  const { data, error } = await supabase
    .from("events")
    .select("id, name, starts_at, location, capacity")
    .order("starts_at", { ascending: false });

  const events: EventItem[] = (data ?? []) as EventItem[];

  return (
    <main className="mx-auto max-w-7xl px-5 py-10">
      <h1 className="text-3xl font-semibold">Events</h1>
      <p className="mt-2 text-neutral-600">
        Registrations, attendance and event history.
      </p>

      {(queryError || error) && (
        <p className="mt-4 text-red-700">
          {queryError || error?.message}
        </p>
      )}

      <form
        action={createEvent}
        className="mt-7 grid gap-3 rounded-2xl border p-5 sm:grid-cols-2"
      >
        <input
          name="name"
          required
          placeholder="Event name"
          className="rounded-xl border px-4 py-3"
        />
        <input
          name="starts_at"
          required
          type="datetime-local"
          className="rounded-xl border px-4 py-3"
        />
        <input
          name="location"
          placeholder="Location"
          className="rounded-xl border px-4 py-3"
        />
        <input
          name="capacity"
          min="1"
          type="number"
          placeholder="Capacity"
          className="rounded-xl border px-4 py-3"
        />
        <button className="rounded-xl bg-black px-4 py-3 text-white sm:col-span-2">
          Create event
        </button>
      </form>

      <div className="mt-6 space-y-3">
        {events.length === 0 ? (
          <p className="text-neutral-600">No events yet.</p>
        ) : (
          events.map((event) => (
            <article key={event.id} className="rounded-2xl border p-5">
              <h2 className="font-semibold">{event.name}</h2>
              <p className="mt-2 text-sm text-neutral-600">
                {new Date(event.starts_at).toLocaleString()} ·{" "}
                {event.location || "Location pending"}
              </p>
              {event.capacity !== null && (
                <p className="mt-1 text-xs text-neutral-500">
                  Capacity: {event.capacity}
                </p>
              )}
            </article>
          ))
        )}
      </div>
    </main>
  );
}
EOF

cat > 'src/app/(app)/customers/[id]/page.tsx' <<'EOF'
import { notFound } from "next/navigation";
import { requireUser } from "@/lib/auth";
import { addNote, addPreference, updatePerson } from "../actions";

type PersonRecord = {
  id: string;
  first_name: string;
  last_name: string | null;
  preferred_name: string | null;
  phone: string | null;
  email: string | null;
  occupation: string | null;
  company: string | null;
};

type NoteRecord = {
  id: string;
  note: string;
  visibility: "barista" | "manager" | "private";
  created_at: string;
};

type PreferenceRecord = {
  id: string;
  preference_type: string;
  preference_value: string;
  created_at: string;
};

type VisitRecord = {
  id: string;
  visited_at: string;
  net_amount: number | null;
  source: string;
};

type MembershipRecord = {
  role: string;
  joined_at: string | null;
  communities: { name: string } | { name: string }[] | null;
};

type RegistrationRecord = {
  status: string;
  registered_at: string;
  events: { name: string; starts_at: string } | { name: string; starts_at: string }[] | null;
};

function relatedName(
  relation: { name: string } | { name: string }[] | null,
): string {
  if (!relation) return "Unknown";
  return Array.isArray(relation)
    ? relation[0]?.name || "Unknown"
    : relation.name;
}

export default async function CustomerPage({
  params,
  searchParams,
}: {
  params: Promise<{ id: string }>;
  searchParams: Promise<{ error?: string }>;
}) {
  const { id } = await params;
  const { error: queryError } = await searchParams;
  const { supabase } = await requireUser();

  const [
    personResult,
    notesResult,
    preferencesResult,
    visitsResult,
    membershipsResult,
    registrationsResult,
  ] = await Promise.all([
    supabase.from("people").select("*").eq("id", id).single(),
    supabase
      .from("customer_notes")
      .select("id, note, visibility, created_at")
      .eq("person_id", id)
      .order("created_at", { ascending: false }),
    supabase
      .from("customer_preferences")
      .select("id, preference_type, preference_value, created_at")
      .eq("person_id", id)
      .order("created_at", { ascending: false }),
    supabase
      .from("visits")
      .select("id, visited_at, net_amount, source")
      .eq("person_id", id)
      .order("visited_at", { ascending: false })
      .limit(20),
    supabase
      .from("community_memberships")
      .select("role, joined_at, communities(name)")
      .eq("person_id", id),
    supabase
      .from("event_registrations")
      .select("status, registered_at, events(name, starts_at)")
      .eq("person_id", id),
  ]);

  const person = personResult.data as PersonRecord | null;
  if (!person) notFound();

  const notes: NoteRecord[] = (notesResult.data ?? []) as NoteRecord[];
  const preferences: PreferenceRecord[] = (preferencesResult.data ?? []) as PreferenceRecord[];
  const visits: VisitRecord[] = (visitsResult.data ?? []) as VisitRecord[];
  const memberships: MembershipRecord[] = (membershipsResult.data ?? []) as MembershipRecord[];
  const registrations: RegistrationRecord[] = (registrationsResult.data ?? []) as RegistrationRecord[];

  const firstError =
    personResult.error ||
    notesResult.error ||
    preferencesResult.error ||
    visitsResult.error ||
    membershipsResult.error ||
    registrationsResult.error;

  const update = updatePerson.bind(null, id);
  const noteAction = addNote.bind(null, id);
  const preferenceAction = addPreference.bind(null, id);

  return (
    <main className="mx-auto max-w-7xl px-5 py-10">
      <div>
        <p className="text-sm uppercase tracking-[0.18em] text-neutral-500">
          Customer profile
        </p>
        <h1 className="mt-2 text-3xl font-semibold">
          {person.preferred_name || person.first_name} {person.last_name || ""}
        </h1>
        <p className="mt-2 text-neutral-600">
          {visits.length} recorded visits · {memberships.length} communities ·{" "}
          {registrations.length} events
        </p>
      </div>

      {(queryError || firstError) && (
        <p className="mt-5 rounded-xl border border-red-300 p-3 text-red-700">
          {queryError || firstError?.message}
        </p>
      )}

      <div className="mt-8 grid gap-6 lg:grid-cols-2">
        <section className="rounded-2xl border p-6">
          <h2 className="text-lg font-semibold">Identity</h2>
          <form action={update} className="mt-5 grid gap-3 sm:grid-cols-2">
            <input
              name="first_name"
              required
              defaultValue={person.first_name}
              className="rounded-xl border px-3 py-2"
            />
            <input
              name="last_name"
              defaultValue={person.last_name || ""}
              placeholder="Last name"
              className="rounded-xl border px-3 py-2"
            />
            <input
              name="preferred_name"
              defaultValue={person.preferred_name || ""}
              placeholder="Preferred name"
              className="rounded-xl border px-3 py-2"
            />
            <input
              name="phone"
              defaultValue={person.phone || ""}
              placeholder="Phone"
              className="rounded-xl border px-3 py-2"
            />
            <input
              name="email"
              type="email"
              defaultValue={person.email || ""}
              placeholder="Email"
              className="rounded-xl border px-3 py-2"
            />
            <input
              name="occupation"
              defaultValue={person.occupation || ""}
              placeholder="Occupation"
              className="rounded-xl border px-3 py-2"
            />
            <input
              name="company"
              defaultValue={person.company || ""}
              placeholder="Company"
              className="rounded-xl border px-3 py-2"
            />
            <button className="rounded-xl bg-black px-4 py-2 text-white sm:col-span-2">
              Save profile
            </button>
          </form>
        </section>

        <section className="rounded-2xl border p-6">
          <h2 className="text-lg font-semibold">Hospitality preferences</h2>
          <form
            action={preferenceAction}
            className="mt-5 grid gap-3 sm:grid-cols-2"
          >
            <input
              name="preference_type"
              required
              placeholder="Type, e.g. seating"
              className="rounded-xl border px-3 py-2"
            />
            <input
              name="preference_value"
              required
              placeholder="Preference"
              className="rounded-xl border px-3 py-2"
            />
            <button className="rounded-xl border px-4 py-2 sm:col-span-2">
              Add preference
            </button>
          </form>

          <div className="mt-5 flex flex-wrap gap-2">
            {preferences.map((item) => (
              <span
                key={item.id}
                className="rounded-full bg-neutral-100 px-3 py-1 text-sm"
              >
                {item.preference_type}: {item.preference_value}
              </span>
            ))}
          </div>
        </section>

        <section className="rounded-2xl border p-6">
          <h2 className="text-lg font-semibold">Notes</h2>
          <form action={noteAction} className="mt-5 space-y-3">
            <textarea
              name="note"
              required
              placeholder="Useful hospitality context"
              className="min-h-24 w-full rounded-xl border p-3"
            />
            <select
              name="visibility"
              className="w-full rounded-xl border p-3"
            >
              <option value="barista">Visible to baristas</option>
              <option value="manager">Managers only</option>
              <option value="private">Private</option>
            </select>
            <button className="rounded-xl border px-4 py-2">Add note</button>
          </form>

          <div className="mt-5 space-y-3">
            {notes.map((note) => (
              <article key={note.id} className="rounded-xl bg-neutral-50 p-4">
                <p>{note.note}</p>
                <p className="mt-2 text-xs text-neutral-500">
                  {note.visibility} ·{" "}
                  {new Date(note.created_at).toLocaleString()}
                </p>
              </article>
            ))}
          </div>
        </section>

        <section className="rounded-2xl border p-6">
          <h2 className="text-lg font-semibold">Relationship timeline</h2>
          <div className="mt-5 space-y-4 text-sm">
            {visits.map((visit) => (
              <div key={visit.id}>
                <p className="font-medium">
                  Visit · {new Date(visit.visited_at).toLocaleDateString()}
                </p>
                <p className="text-neutral-500">
                  {visit.net_amount !== null
                    ? `₹${visit.net_amount}`
                    : visit.source}
                </p>
              </div>
            ))}

            {memberships.map((membership, index) => (
              <div key={`membership-${index}`}>
                <p className="font-medium">
                  Community · {relatedName(membership.communities)}
                </p>
                <p className="text-neutral-500">{membership.role}</p>
              </div>
            ))}

            {registrations.map((registration, index) => (
              <div key={`registration-${index}`}>
                <p className="font-medium">
                  Event · {relatedName(registration.events)}
                </p>
                <p className="text-neutral-500">{registration.status}</p>
              </div>
            ))}

            {!visits.length &&
              !memberships.length &&
              !registrations.length && (
                <p className="text-neutral-500">
                  No timeline activity yet.
                </p>
              )}
          </div>
        </section>
      </div>
    </main>
  );
}
EOF

cat > 'src/app/(app)/dashboard/page.tsx' <<'EOF'
import Link from "next/link";
import { requireUser } from "@/lib/auth";

export default async function DashboardPage() {
  const { supabase } = await requireUser();

  const [
    peopleResult,
    communitiesResult,
    eventsResult,
    visitsResult,
  ] = await Promise.all([
    supabase.from("people").select("*", { count: "exact", head: true }),
    supabase
      .from("communities")
      .select("*", { count: "exact", head: true }),
    supabase.from("events").select("*", { count: "exact", head: true }),
    supabase.from("visits").select("*", { count: "exact", head: true }),
  ]);

  const cards = [
    ["Customers", peopleResult.count ?? 0, "/customers"],
    ["Visits", visitsResult.count ?? 0, "/customers"],
    ["Communities", communitiesResult.count ?? 0, "/communities"],
    ["Events", eventsResult.count ?? 0, "/events"],
  ] as const;

  const firstError =
    peopleResult.error ||
    communitiesResult.error ||
    eventsResult.error ||
    visitsResult.error;

  return (
    <main className="mx-auto max-w-7xl px-5 py-10">
      <h1 className="text-3xl font-semibold">Dashboard</h1>
      <p className="mt-2 text-neutral-600">
        The café relationship layer at a glance.
      </p>

      {firstError && (
        <p className="mt-5 rounded-xl border border-red-300 p-3 text-red-700">
          {firstError.message}
        </p>
      )}

      <div className="mt-8 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        {cards.map(([label, value, href]) => (
          <Link
            key={label}
            href={href}
            className="rounded-2xl border p-5"
          >
            <p className="text-sm text-neutral-500">{label}</p>
            <p className="mt-2 text-3xl font-semibold">{value}</p>
          </Link>
        ))}
      </div>

      <div className="mt-8 rounded-2xl border p-6">
        <h2 className="text-lg font-semibold">Start here</h2>
        <p className="mt-2 text-sm text-neutral-600">
          Claim the first admin role in Settings, then add customers,
          communities and events.
        </p>
      </div>
    </main>
  );
}
EOF

# Ensure generated tool files do not create permanent Git noise.
cat >> .gitignore <<'EOF'

# Local MVP repair tooling
MVP_REPAIR_LOG_*.txt
repair-11thbean-mvp.command
.mvp-repair-backups/
EOF

pass "Rewrote all generated data-reading pages with explicit null-safe types"

printf "\nRunning lint...\n"
npm run lint
pass "Lint passed"

printf "\nRunning full production build...\n"
npm run build
pass "Production build passed"

printf "\nRunning route collision check...\n"
if [[ -f "src/app/customers/page.tsx" && -f "src/app/(app)/customers/page.tsx" ]]; then
  fail "Duplicate /customers route still exists"
  exit 1
fi
pass "No duplicate /customers route"

REPORT="$ROOT/MVP_REPAIR_REPORT_${STAMP}.txt"
cat > "$REPORT" <<EOF
THE 11TH BEAN MVP REPAIR REPORT
Generated: $(date)

Project: $ROOT
Backup: $BACKUP
Log: $LOG

COMPLETED
- Removed duplicate /customers route
- Rewrote customer listing with null-safe typed data
- Rewrote customer profile with null-safe typed relations
- Rewrote communities page with null-safe typed data
- Rewrote events page with null-safe typed data
- Rewrote dashboard count handling
- Passed npm lint
- Passed complete production build

STATUS: READY FOR COMMIT AND DEPLOYMENT

The repair script deliberately did not commit or deploy.
EOF

printf "\n"
pass "Repair complete"
printf "Report: %s\n" "$REPORT"
printf "Backup: %s\n" "$BACKUP"
printf "Log: %s\n" "$LOG"
open "$REPORT" >/dev/null 2>&1 || true

read -r -p "Press Enter to close..."
